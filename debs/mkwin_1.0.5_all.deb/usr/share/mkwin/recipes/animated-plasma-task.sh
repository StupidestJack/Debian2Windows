# animated-plasma-task —— KDE Plasma 6 任务栏动画（按下/进入/最小化动效）
# https://github.com/SkyShadowHero/Animated-plasma-task
pkg_name="animated-plasma-task"
pkg_desc="带 Windows 风格任务栏动画的 KDE Plasma 6 小组件（图标任务栏/开始菜单/任务管理器）"
pkg_url="https://github.com/SkyShadowHero/Animated-plasma-task"
pkg_license="GPL-2.0"
pkg_category="gui"
pkg_tag="practical"
pkg_prefix="/usr"    # Plasma 只扫描系统 Qt 插件路径，必须装到 /usr
pkg_needs="cmake ninja"
pkg_deps_arch="extra-cmake-modules plasma-workspace kservice kirigami kiconthemes ksvg kio krunner kdeclarative qt6-declarative kcoreaddons kconfig kwindowsystem kglobalaccel kcmutils libplasma plasma-activities-stats libksysguard notification-manager"
pkg_note="仅 KDE Plasma 6 桌面生效；安装后需手动把任务栏切换为 skyler 版组件"

build() {
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
          -DCMAKE_INSTALL_PREFIX="$MKWIN_PREFIX"
    cmake --build build -j"$(nproc)"
}

package() {
    DESTDIR="$pkgdir" cmake --install build
}
