# windowshit —— 24 个 Windows 命令行工具的 Rust 重写
# https://github.com/HelloAIXIAOJI/windowshit
pkg_name="windowshit"
pkg_desc="Rust 重写的 24 个 Windows 命令：ipconfig/tasklist/robocopy/findstr 等"
pkg_url="https://github.com/HelloAIXIAOJI/windowshit"
pkg_license="MIT"
pkg_category="cli"
pkg_tag="practical"
pkg_needs="cargo make"
pkg_note="安装 ipconfig/ping/sort/tree 等 24 个命令到 $MKWIN_PREFIX/bin；若 /usr/local/bin 在 PATH 中靠前，会覆盖同名系统命令的观感（这正是项目目的）"

build() {
    make build
}

package() {
    make -C "$srcdir" install ROOT="$pkgdir$MKWIN_PREFIX"
}
