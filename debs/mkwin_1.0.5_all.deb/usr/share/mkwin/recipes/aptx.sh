# aptx —— apt 包装器：安装后推荐“捆绑软件”，复刻 Windows 全家桶体验
# https://github.com/WenAnrong/aptx
pkg_name="aptx"
pkg_desc="apt 包装器：装完软件顺手推荐全家桶，复刻 Windows 捆绑安装体验"
pkg_url="https://github.com/WenAnrong/aptx"
pkg_license="MIT"
pkg_category="cli"
pkg_tag="prank"
pkg_needs="python3"
pkg_deps_debian="python3 python3-apt python3-distro debtags"
pkg_note="依赖 apt/python-apt，仅 Debian 系发行版可用；Arch 上安装仅供收藏"

package() {
    install -d "$pkgdir$MKWIN_PREFIX/lib"
    cp -r "$srcdir/src/aptx" "$pkgdir$MKWIN_PREFIX/lib/aptx"
    find "$pkgdir" -type d -name __pycache__ -exec rm -rf {} +
    inst_script aptx <<EOF
#!/usr/bin/env python3
import sys
sys.path.insert(0, "$MKWIN_PREFIX/lib/aptx")
from aptx.cli import main
sys.exit(main())
EOF
}
