# mmclinux —— tkinter 复刻 Windows 管理控制台（MDI + 管理单元）
# https://gitee.com/windowsuninstaller/mmclinux
pkg_name="mmclinux"
pkg_desc="tkinter 模拟 Windows MMC 管理控制台：MDI 子窗口、管理单元、可扩展"
pkg_url="https://gitee.com/windowsuninstaller/mmclinux"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="python3"
pkg_deps_debian="python3 python3-tk"
pkg_deps_fedora="python3 python3-tkinter"
pkg_note="自定义管理单元：在 share/mkwin/mmclinux/msc/ 下放 .py 文件即可"

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/mmclinux"
    install -d "$d"
    local f
    for f in main.py mmcmenu.py about.py language.py README.md; do
        [[ -e "$srcdir/$f" ]] && install -m644 "$srcdir/$f" "$d/"
    done
    cp -r "$srcdir/language" "$srcdir/msc" "$d/"
    inst_script mmclinux <<EOF
#!/bin/sh
cd "$MKWIN_PREFIX/share/mkwin/mmclinux" || exit 1
exec python3 main.py "\$@"
EOF
    inst_desktop mmclinux "MMC 管理控制台" \
        "$MKWIN_PREFIX/bin/mmclinux" utilities-system-monitor "System;Utility;"
}
