# taskschd —— Linux 任务计划程序（计划任务 GUI，PySide6）
# https://github.com/1ctrl-cv/taskschd4Linux
pkg_name="taskschd"
pkg_desc="Windows 任务计划程序克隆：管理 cron/at 计划任务（PySide6 GUI，独立 venv）"
pkg_url="https://github.com/1ctrl-cv/taskschd4Linux"
pkg_license="未注明"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="python3"
pkg_deps_debian="python3 python3-venv"
pkg_note="PySide6/croniter 安装到独立 venv，构建阶段需联网；运行需要桌面环境的 GL/X11 基础库"

package() {
    local vdir="$pkgdir$MKWIN_PREFIX/share/mkwin/venvs/taskschd"
    python3 -m venv "$vdir" || return 1
    "$vdir/bin/pip" install --quiet PySide6 croniter || return 1
    local f
    while IFS= read -r -d '' f; do
        sed -i "s|$pkgdir||g" "$f"
    done < <(grep -rIlZ "$pkgdir" "$vdir" 2>/dev/null)

    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/taskschd"
    install -d "$d"
    install -m644 "$srcdir/main.py" "$d/"
    cp -r "$srcdir/ltask" "$d/ltask"
    inst_script taskschd <<EOF
#!/bin/sh
cd "$MKWIN_PREFIX/share/mkwin/taskschd" || exit 1
exec "$MKWIN_PREFIX/share/mkwin/venvs/taskschd/bin/python" main.py "\$@"
EOF
    inst_desktop taskschd "任务计划程序" \
        "$MKWIN_PREFIX/bin/taskschd" utilities-tasks "System;Utility;"
}
