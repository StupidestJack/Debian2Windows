# linux-uac —— PAM 模块：sudo 时复刻 UAC（屏幕变暗 + 密码框）
# https://github.com/WenAnrong/Linux_uac
pkg_name="linux-uac"
pkg_desc="PAM 模块：执行 sudo 时屏幕变暗弹出 UAC 风格确认框（SDL2 双后端）"
pkg_url="https://github.com/WenAnrong/Linux_uac"
pkg_license="MIT"
pkg_category="system"
pkg_tag="prank"
pkg_needs="cc make pkg-config"
pkg_deps_arch="pam libxcrypt libx11 sdl2 sdl2_ttf sdl2_image"
pkg_deps_debian="libpam0g-dev libcrypt-dev libx11-dev libsdl2-dev libsdl2-ttf-dev libsdl2-image-dev"
pkg_deps_fedora="pam-devel libxcrypt-devel libX11-devel SDL2-devel SDL2_ttf-devel SDL2_image-devel"
pkg_note="mkwin 只安装模块，不改 /etc/pam.d；启用方法见上游 install.sh：在 /etc/pam.d/sudo 顶部加一行 auth sufficient pam_uac.so（卸载前记得删除该行）"

build() {
    make UAC_UI_PATH="$MKWIN_PREFIX/libexec/linux-uac/uac_ui"
}

package() {
    local pamdir
    for pamdir in /usr/lib/security /usr/lib64/security /lib/security; do
        [[ -d "$pamdir" ]] && break
    done
    [[ -d "$pamdir" ]] || { echo "linux-uac：找不到 PAM 模块目录" >&2; return 1; }
    install -Dm755 "$srcdir/pam_uac.so" "$pkgdir$pamdir/pam_uac.so"
    install -Dm755 "$srcdir/uac_ui" \
        "$pkgdir$MKWIN_PREFIX/libexec/linux-uac/uac_ui"
}
