# explorer —— Win11 风格文件资源管理器（Electron + Vue + WinUI 组件）
# https://github.com/xbodwf/explorer-for-linux   （用户指定使用 xbodwf 版）
pkg_name="explorer"
pkg_desc="Win11 风格文件管理器：electron-vite + Vue + WinUI 风格组件（xbodwf 版）"
pkg_url="https://github.com/xbodwf/explorer-for-linux"
pkg_license="GPL-3.0"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="node npm"
pkg_note="Electron 应用，首次构建需联网下载 Electron 运行时，耗时较长"

build() {
    local pn
    if command -v pnpm >/dev/null 2>&1; then
        pn=(pnpm)
    elif command -v corepack >/dev/null 2>&1; then
        pn=(corepack pnpm)
    else
        pn=(npx --yes pnpm)
    fi
    "${pn[@]}" install --frozen-lockfile || "${pn[@]}" install
    "${pn[@]}" build        # vue-tsc && vite build && electron-builder -> AppImage
}

package() {
    local appimg
    appimg="$(find "$srcdir/release" -type f -name '*.AppImage' | head -1)"
    [[ -n "$appimg" ]] || { echo "explorer：未找到构建出的 AppImage" >&2; return 1; }
    install -Dm755 "$appimg" "$pkgdir$MKWIN_PREFIX/share/mkwin/explorer/explorer.AppImage"
    inst_script explorer <<EOF
#!/bin/sh
exec "$MKWIN_PREFIX/share/mkwin/explorer/explorer.AppImage" "\$@"
EOF
    inst_desktop explorer "Explorer for Linux" \
        "$MKWIN_PREFIX/bin/explorer" system-file-manager "FileManager;Utility;"
}
