# winget —— Windows 包管理器 winget 的 Linux 克隆
# https://github.com/jihan-hanhan/Winget-for-Linux
pkg_name="winget"
pkg_desc="winget CLI 体验移植：在 Linux 上享受 winget install 的快乐"
pkg_url="https://github.com/jihan-hanhan/Winget-for-Linux"
pkg_license="未注明"
pkg_category="cli"
pkg_tag="prank"
pkg_needs="cargo"

build() {
    cargo build --release
}

package() {
    inst_bin "$srcdir/target/release/winget" winget
}
