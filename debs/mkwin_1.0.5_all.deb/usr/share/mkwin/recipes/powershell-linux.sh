# powershell-linux —— 真正的 PowerShell 风格解释器（纯 Go）
# https://github.com/SweetenedSuzuka/PowerShell-For-Linux
pkg_name="powershell-linux"
pkg_desc="PowerShell 风格解释器：对象管道、114 个内置 cmdlet、.ps1 脚本，零第三方依赖（用 PowerShell 风格的命令控制 Linux）"
pkg_url="https://github.com/SweetenedSuzuka/PowerShell-For-Linux"
pkg_license="MIT"
pkg_category="cli"
pkg_tag="practical"
pkg_needs="go"

build() {
    go build -o powershell .
}

package() {
    inst_bin "$srcdir/powershell" powershell
}