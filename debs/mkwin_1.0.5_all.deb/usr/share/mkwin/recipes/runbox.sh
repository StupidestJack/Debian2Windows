# runbox —— Win+R 风格运行对话框（GTK4 + libadwaita）
# https://github.com/HelloAIXIAOJI/runbox
pkg_name="runbox"
pkg_desc="Win+R 风格运行对话框，Adwaita 风格，支持全局快捷键"
pkg_url="https://github.com/HelloAIXIAOJI/runbox"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="cargo pkg-config"
pkg_deps_arch="gtk4 libadwaita"
pkg_deps_debian="libgtk-4-dev libadwaita-1-dev"
pkg_deps_fedora="gtk4-devel libadwaita-devel"

build() {
    cargo build --release
}

package() {
    inst_bin "$srcdir/target/release/runbox" runbox
    inst_desktop runbox Runbox \
        "$MKWIN_PREFIX/bin/runbox" system-run "Utility;"
}
