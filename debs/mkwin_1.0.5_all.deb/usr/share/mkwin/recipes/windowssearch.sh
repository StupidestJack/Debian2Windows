# windowssearch —— 复刻 Windows 任务栏搜索（含“折腾人”体验）
# https://github.com/WhatDamon/WindowsSearch
pkg_name="windowssearch"
pkg_desc="复刻 Windows 任务栏搜索：你搜的不是你想搜的"
pkg_url="https://github.com/WhatDamon/WindowsSearch"
pkg_license="WTFPL"
pkg_category="gui"
pkg_tag="prank"
pkg_needs="python3 make"
pkg_deps_debian="python3 python3-venv"
pkg_note="PyInstaller 打包，构建阶段需联网安装构建依赖"

build() {
    make build
}

package() {
    inst_bin "$srcdir/dist/windows-search" windows-search
    inst_desktop windowssearch "Windows 搜索" \
        "$MKWIN_PREFIX/bin/windows-search" system-search "Utility;System;"
}
