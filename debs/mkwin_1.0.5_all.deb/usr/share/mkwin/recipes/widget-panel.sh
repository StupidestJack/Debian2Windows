# widget-panel —— Windows 11 小组件面板
# https://github.com/phillin-liu/WindowsWidget-for-Linux
pkg_name="widget-panel"
pkg_desc="Win11 小组件面板：屏幕右侧滑入，集成新闻/天气/时钟与图形设置（PyQt5）"
pkg_url="https://github.com/phillin-liu/WindowsWidget-for-Linux"
pkg_license="未注明"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="python3"
pkg_deps_arch="python-pyqt5 python-requests python-pillow"
pkg_deps_debian="python3 python3-pyqt5 python3-requests python3-pil"
pkg_deps_fedora="python3-qt5 python3-requests python3-pillow"

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/widget-panel"
    install -d "$d"
    cp -r "$srcdir/widget_panel" "$d/widget_panel"
    # 生成多尺寸图标（失败不阻塞，仅损失图标）
    python3 "$srcdir/scripts/generate_icon.py" \
        "$pkgdir$MKWIN_PREFIX/share/icons/hicolor" >/dev/null 2>&1 || true
    inst_script widget-panel <<EOF
#!/bin/sh
export PYTHONPATH="$MKWIN_PREFIX/share/mkwin/widget-panel\${PYTHONPATH:+:\$PYTHONPATH}"
exec python3 -m widget_panel.main "\$@"
EOF
    inst_desktop widget-panel "Windows 小组件" \
        "$MKWIN_PREFIX/bin/widget-panel" widget-panel "Utility;Network;"
}
