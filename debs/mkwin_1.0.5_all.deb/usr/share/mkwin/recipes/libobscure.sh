# libobscure —— LD_PRELOAD 库：把报错替换成 Windows 风格错误码
# https://github.com/LyCecilion/libobscure
pkg_name="libobscure"
pkg_desc="LD_PRELOAD 整活库：把 strerror/perror 换成 Something went wrong. Error code: 0x8007xxxx"
pkg_url="https://github.com/LyCecilion/libobscure"
pkg_license="MIT"
pkg_category="system"
pkg_tag="prank"
pkg_needs="cc make"
pkg_note="用法：LD_PRELOAD=$MKWIN_PREFIX/lib/libobscure.so <命令>"

build() {
    make
}

package() {
    install -Dm755 "$srcdir/build/libobscure.so" \
        "$pkgdir$MKWIN_PREFIX/lib/libobscure.so"
}
