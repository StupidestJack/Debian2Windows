# winupdate —— 假 Windows 更新屏幕：50% 真更新，50% 蓝屏
# https://github.com/WenAnrong/windows_update_in_linux
pkg_name="winupdate"
pkg_desc="全屏假 Windows 更新：50% 概率执行真实更新重启，50% 概率蓝屏"
pkg_url="https://github.com/WenAnrong/windows_update_in_linux"
pkg_license="MIT"
pkg_category="lowlevel"
pkg_tag="prank"
pkg_needs="cc cmake ninja pkg-config"
pkg_deps_arch="libdrm freetype2 fontconfig"
pkg_deps_debian="libdrm-dev libfreetype-dev libfontconfig-dev"
pkg_deps_fedora="libdrm-devel freetype-devel fontconfig-devel"
pkg_note="有 50% 概率真的重启系统更新！请勿在不合适的时候运行"

build() {
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build -j"$(nproc)"
}

package() {
    # 该项目把产物直接输出到源码根目录（CMAKE_RUNTIME_OUTPUT_DIRECTORY）
    inst_bin "$srcdir/windows_update_in_linux" windows_update_in_linux
}
