# cmd —— 纯 C89 从零实现的 cmd.exe 克隆（40+ 内置命令、批处理）
# https://github.com/ChenPi11/cmd
pkg_name="cmd"
pkg_desc="纯 C89 手写的 cmd.exe 克隆：批处理脚本与 40+ 内置命令"
pkg_url="https://github.com/ChenPi11/cmd"
pkg_license="GPL-3.0"
pkg_category="cli"
pkg_tag="practical"
pkg_needs="cc make"

build() {
    make -j"$(nproc)"
}

package() {
    # 不用上游 make install：其 ln -sfn 会把符号链接指向 $pkgdir 暂存路径
    install -Dm755 "$srcdir/cmd.exe"      "$pkgdir$MKWIN_PREFIX/bin/cmd.exe"
    install -Dm755 "$srcdir/COMMAND.COM"  "$pkgdir$MKWIN_PREFIX/bin/COMMAND.COM"
    ln -s cmd.exe "$pkgdir$MKWIN_PREFIX/bin/cmd"
}
