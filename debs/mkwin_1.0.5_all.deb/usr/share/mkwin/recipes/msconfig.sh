# msconfig —— Linux 系统配置工具
# https://github.com/macOS-Terminal/msconfig-for-linux
pkg_name="msconfig"
pkg_desc="Windows msconfig 移植：管理启动项、服务、内核参数、systemd 单元的图形化配置工具（Qt6）"
pkg_url="https://github.com/macOS-Terminal/msconfig-for-linux"
pkg_license="GPL-3.0"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="cc cmake pkg-config"
pkg_deps_arch="qt6-base qt6-tools cmake"
pkg_deps_debian="qt6-base-dev qt6-tools-dev cmake"
pkg_deps_fedora="qt6-qtbase-devel qt6-qttools-devel cmake"
pkg_note="CMakeLists.txt 无 install() 规则，手动安装；若 gcc 链接报 copy relocation 错误会自动回退到 clang++"

build() {
    rm -rf build   # 上游把作者本机生成的 build/CMakeCache.txt 提交进了仓库，必须先清掉
    mkdir -p build && cd build
    cmake .. -DCMAKE_BUILD_TYPE=Release || return 1
    if ! make; then
        command -v clang++ >/dev/null || return 1
        make clean
        make CXX=clang++
    fi
}

package() {
    inst_bin "$srcdir/build/msconfig" msconfig
    inst_desktop msconfig "系统配置 (msconfig)" \
        "$MKWIN_PREFIX/bin/msconfig" preferences-system "System;Settings;"
}
