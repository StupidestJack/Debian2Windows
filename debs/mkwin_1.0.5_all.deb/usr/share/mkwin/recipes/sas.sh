# sas —— Win11 风格 Ctrl+Alt+Delete 安全屏幕（C++/Qt6，X11+Wayland）
# https://github.com/macOS-Terminal/SAS-for-Linux
pkg_name="sas"
pkg_desc="Win11 风格 Ctrl+Alt+Delete 屏幕：毛玻璃全屏覆盖 + 锁定/切换用户/任务管理器"
pkg_url="https://github.com/macOS-Terminal/SAS-for-Linux"
pkg_license="未注明"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="cmake ninja g++ pkg-config"
pkg_deps_arch="qt6-base libxcb"
pkg_deps_debian="qt6-base-dev libxcb1-dev"
pkg_deps_fedora="qt6-qtbase-devel libxcb-devel"
pkg_note="快捷键绑定与 systemd 屏蔽请参考上游 deploy/install.sh（mkwin 不自动配置）"

build() {
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
          -DCMAKE_INSTALL_PREFIX="$MKWIN_PREFIX"
    cmake --build build -j"$(nproc)"
}

package() {
    DESTDIR="$pkgdir" cmake --install build
}
