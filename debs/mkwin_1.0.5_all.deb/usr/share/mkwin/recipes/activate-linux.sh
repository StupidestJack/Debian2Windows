# activate-linux —— 桌面右下角“激活 Linux”水印
# https://github.com/MrGlockenspiel/activate-linux
pkg_name="activate-linux"
pkg_desc="在桌面右下角显示“激活 Linux — 转到设置以激活 Linux”水印（Wayland/X11）"
pkg_url="https://github.com/MrGlockenspiel/activate-linux"
pkg_license="GPL-3.0"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="cc make pkg-config"
pkg_deps_arch="cairo pango wayland libx11 libxfixes libxinerama libxrandr libxext libconfig"
pkg_deps_debian="libcairo2-dev libpango1.0-dev libwayland-dev libx11-dev libxfixes-dev libxinerama-dev libxrandr-dev libxext-dev libconfig-dev"
pkg_deps_fedora="cairo-devel pango-devel wayland-devel libX11-devel libXfixes-devel libXinerama-devel libXrandr-devel libXext-devel libconfig-devel"

build() {
    make    # 默认 wayland+x11 双后端
}

package() {
    make install DESTDIR="$pkgdir" PREFIX="$MKWIN_PREFIX"
}
