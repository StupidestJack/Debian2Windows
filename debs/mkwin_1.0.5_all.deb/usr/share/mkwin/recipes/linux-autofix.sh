# linux-autofix —— 自动修复（模拟）
# https://github.com/xusk1234/Linux-Auto-Fix
pkg_name="linux-autofix"
pkg_desc="Windows 启动修复复刻：扫描系统后建议你「恢复到 Ubuntu 默认设置」就完事了（tkinter，无额外依赖）"
pkg_url="https://github.com/xusk1234/Linux-Auto-Fix"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="prank"
pkg_needs="python3"
pkg_deps_arch="python3"
pkg_deps_debian="python3-tk"
pkg_deps_fedora="python3-tkinter"

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/linux-autofix"
    install -d "$d"
    install -m644 "$srcdir/Linux-Auto-Fix.py" "$d/"
    inst_script linux-autofix <<EOF
#!/bin/sh
exec python3 "$MKWIN_PREFIX/share/mkwin/linux-autofix/Linux-Auto-Fix.py" "\$@"
EOF
    inst_desktop linux-autofix "自动修复" \
        "$MKWIN_PREFIX/bin/linux-autofix" system-run "System;Utility;"
}