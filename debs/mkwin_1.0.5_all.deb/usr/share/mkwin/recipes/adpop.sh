# adpop —— 广告弹窗服务（Wayland/X11 弹出不可关闭的动画广告）
# https://github.com/MEKCCK/adpop
pkg_name="adpop"
pkg_desc="广告弹窗服务：批量弹出不可关闭的动画广告窗口"
pkg_url="https://github.com/MEKCCK/adpop"
pkg_license="未注明"
pkg_category="system"
pkg_tag="prank"
pkg_needs="cargo"
pkg_deps_arch="rust wayland"
pkg_deps_debian="cargo libwayland-dev"
pkg_deps_fedora="rust wayland-devel"
pkg_note="手动运行 adpop 拉起弹窗，仅供整活，请勿在生产机器常驻"

build() {
    cargo build --release --locked
}

package() {
    inst_bin "$srcdir/target/release/adpop" adpop
}
