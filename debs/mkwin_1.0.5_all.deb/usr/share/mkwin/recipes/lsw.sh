# lsw —— Linux Subsystem for Windows：在 Linux 上跑 Windows 程序（WSL 反向整活）
# https://github.com/LING71671/lsw
pkg_name="lsw"
pkg_desc="Linux Subsystem for Windows：像 WSL 之于 Windows 一样，在 Linux 上直接运行 .exe（wine 引擎 + binfmt_misc）"
pkg_url="https://github.com/LING71671/lsw"
pkg_license="MIT"
pkg_category="lowlevel"
pkg_tag="practical"
pkg_prefix="/usr"    # 上游 binfmt_misc 注册路径为 /usr/bin/lsw-exec
pkg_needs="cargo"
pkg_deps_arch="wine"
pkg_deps_debian="wine"
pkg_deps_fedora="wine"
pkg_note="mkwin 只装二进制与配置样例，不自动注册 binfmt_misc/不自启 lswd；启用见上游 install.sh：echo ':LSW-PE:M:0:MZ::/usr/bin/lsw-exec:CF' > /proc/sys/fs/binfmt_misc/register 并 systemctl enable --now lswd"

build() {
    cargo build --release --workspace --locked
}

package() {
    # 注意：CLI crate 产物名是 lsw-cli，安装为 lsw（其余三个名字一致）
    install -Dm755 "$srcdir/target/release/lsw-cli" "$pkgdir$MKWIN_PREFIX/bin/lsw"
    local b
    for b in lswpath lsw-exec lswd; do
        install -Dm755 "$srcdir/target/release/$b" "$pkgdir$MKWIN_PREFIX/bin/$b"
    done
    install -Dm644 "$srcdir/packaging/lswd.service" \
        "$pkgdir$MKWIN_PREFIX/lib/systemd/system/lswd.service"
    # 默认前缀走真实 /etc；自定义前缀（沙箱/定制布局）时收进前缀内
    local etcdir="/etc"
    [[ "$MKWIN_PREFIX" != "/usr" && "$MKWIN_PREFIX" != "/usr/local" ]] && etcdir="$MKWIN_PREFIX/etc"
    if [[ ! -e "$etcdir/lsw/lsw.conf" ]]; then
        install -Dm644 /dev/stdin "$pkgdir$etcdir/lsw/lsw.conf" <<'EOF'
[automount]
enabled = true
mountFsTab = true
root = "/mnt/w/"
options = "metadata,uid=1000,gid=1000,umask=022,case=default"

[interop]
enabled = true
appendWindowsPath = true

[user]
default = "lswuser"

[boot]
systemd = true
command = "/usr/libexec/lsw/boot.sh"
EOF
    fi
}
