# explorer-prank —— Win11 文件资源管理器整活版（含“未响应”卡死恶搞）
# https://github.com/macOS-Terminal/Explorer-for-Linux
pkg_name="explorer-prank"
pkg_desc="Win11 文件管理器整活克隆：经典“程序未响应”白屏卡死恶搞"
pkg_url="https://github.com/macOS-Terminal/Explorer-for-Linux"
pkg_license="未注明"
pkg_category="gui"
pkg_tag="prank"
pkg_conflicts="explorer"   # 与 xbodwf 版安装同名的 explorer 二进制
pkg_needs="cmake ninja g++ pkg-config"
pkg_deps_arch="qt6-base libxcb xcb-util-keysyms wayland"
pkg_deps_debian="qt6-base-dev libxcb-keysyms1-dev libwayland-dev"
pkg_deps_fedora="qt6-qtbase-devel xcb-util-keysyms-devel libwayland-devel"
pkg_note="仅安装二进制，不启用守护/自启动；完整恶搞体验参考上游 scripts/install.sh apply"

build() {
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
          -DCMAKE_INSTALL_PREFIX="$MKWIN_PREFIX"
    cmake --build build -j"$(nproc)"
}

package() {
    DESTDIR="$pkgdir" cmake --install build
}
