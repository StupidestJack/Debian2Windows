# openconsole —— Microsoft OpenConsole 引擎的 Linux 移植（Qt6 前端）
# https://github.com/lanlan1o/openconsole_linux
pkg_name="openconsole"
pkg_desc="微软 OpenConsole 终端引擎的 Linux 移植：Qt6 前端 + 伪终端 + VT 解析"
pkg_url="https://github.com/lanlan1o/openconsole_linux"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="cmake ninja g++"
pkg_deps_arch="qt6-base icu fmt"
pkg_deps_debian="qt6-base-dev libicu-dev libfmt-dev"
pkg_deps_fedora="qt6-qtbase-devel libicu-devel fmt-devel"

build() {
    cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
    cmake --build build -j"$(nproc)"
}

package() {
    inst_bin "$srcdir/build/openconsole_linux" openconsole_linux
}
