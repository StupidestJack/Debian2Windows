# lindows-troubleshooting —— “疑难解答”：白嫖你人生中宝贵的一分钟
# https://github.com/BobbyChengCN0518/Lindows-Troubleshooting
pkg_name="lindows-troubleshooting"
pkg_desc="Windows 疑难解答复刻：开始检测后请等待，将浪费你人生中宝贵的一分钟（PySide6）"
pkg_url="https://github.com/BobbyChengCN0518/Lindows-Troubleshooting"
pkg_license="未注明"
pkg_category="gui"
pkg_tag="prank"
pkg_needs="python3"
pkg_deps_arch="pyside6"
pkg_deps_debian="pyside6"
pkg_deps_fedora="python3-pyside6"

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/lindows-troubleshooting"
    install -d "$d"
    install -m644 "$srcdir/main.py" "$d/"
    inst_script lindows-troubleshooting <<EOF
#!/bin/sh
exec python3 "$MKWIN_PREFIX/share/mkwin/lindows-troubleshooting/main.py" "\$@"
EOF
}
