# lindows-control —— Linux 上能用的“控制面板”
# https://github.com/BobbyChengCN0518/Lindows_Control
pkg_name="lindows-control"
pkg_desc="egui 编写的 Windows 风格控制面板，支持中英文切换"
pkg_url="https://github.com/BobbyChengCN0518/Lindows_Control"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="prank"
pkg_needs="cargo"

build() {
    cargo build --release --locked
}

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/lindows-control"
    install -d "$d"
    install -m755 "$srcdir/target/release/Lindows_Control" "$d/Lindows_Control"
    cp -r "$srcdir/lang" "$d/lang"
    inst_script lindows-control <<EOF
#!/bin/sh
cd "$MKWIN_PREFIX/share/mkwin/lindows-control" || exit 1
exec ./Lindows_Control "\$@"
EOF
    inst_desktop lindows-control "Lindows 控制面板" \
        "$MKWIN_PREFIX/bin/lindows-control" preferences-system "Settings;Utility;"
}
