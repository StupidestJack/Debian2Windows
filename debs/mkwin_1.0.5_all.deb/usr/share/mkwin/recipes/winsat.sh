# winsat —— WinSAT 体验指数的跨平台 Python 移植
# https://github.com/WhatDamon/WinSAT
pkg_name="winsat"
pkg_desc="Windows 体验指数（WEI）移植：CPU/内存/磁盘/图形评分与 GUI"
pkg_url="https://github.com/WhatDamon/WinSAT"
pkg_license="WTFPL"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="python3"
pkg_deps_debian="python3 python3-venv"
pkg_note="安装到独立 venv；GUI 需要 [full] 附加依赖（numpy/Pillow/pyglet），离线时自动降级为核心功能"

package() {
    local vdir="$pkgdir$MKWIN_PREFIX/share/mkwin/venvs/winsat"
    python3 -m venv "$vdir" || return 1
    # 优先带 GUI 附加依赖安装；离线/失败时退回核心
    "$vdir/bin/pip" install --quiet "$srcdir[full]" \
        || "$vdir/bin/pip" install --quiet "$srcdir" || return 1

    # venv 内记录的是打包时的绝对路径（$pkgdir 前缀），
    # 去掉前缀即得到最终安装路径，直接替换使其可用
    local f
    while IFS= read -r -d '' f; do
        sed -i "s|$pkgdir||g" "$f"
    done < <(grep -rIlZ "$pkgdir" "$vdir" 2>/dev/null)

    inst_script winsat <<EOF
#!/bin/sh
exec "$MKWIN_PREFIX/share/mkwin/venvs/winsat/bin/winsat" "\$@"
EOF
}
