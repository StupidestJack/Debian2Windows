# linuxdefender —— Windows Defender 克隆（整活：非功能性杀毒软件）
# https://github.com/xusk1234/LinuxDefender
pkg_name="linuxdefender"
pkg_desc="Windows 安全中心/Defender 复刻整活：一个不知道有啥用的「杀毒软件」（PyQt5 + qfluentwidgets）"
pkg_url="https://github.com/xusk1234/LinuxDefender"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="prank"
pkg_needs="python3"
pkg_deps_arch="python3"
pkg_deps_debian="python3-venv"
pkg_deps_fedora="python3"
pkg_note="PyQt-Fluent-Widgets（含 PyQt5）通过 pip 安装到独立 venv，构建阶段需联网"

package() {
    local vdir="$pkgdir$MKWIN_PREFIX/share/mkwin/venvs/linuxdefender"
    python3 -m venv "$vdir" || return 1
    "$vdir/bin/pip" install --quiet PyQt-Fluent-Widgets || return 1
    local f
    while IFS= read -r -d '' f; do
        sed -i "s|$pkgdir||g" "$f"
    done < <(grep -rIlZ "$pkgdir" "$vdir" 2>/dev/null)

    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/linuxdefender"
    install -d "$d"
    install -m644 "$srcdir/Linux Defender.py" "$d/"
    inst_script linuxdefender <<EOF
#!/bin/sh
VENV="$MKWIN_PREFIX/share/mkwin/venvs/linuxdefender"
export PYTHONPATH="$MKWIN_PREFIX/share/mkwin/linuxdefender\${PYTHONPATH:+:\$PYTHONPATH}"
exec "\$VENV/bin/python" "$MKWIN_PREFIX/share/mkwin/linuxdefender/Linux Defender.py" "\$@"
EOF
    inst_desktop linuxdefender "Windows 安全中心" \
        "$MKWIN_PREFIX/bin/linuxdefender" security-high "System;Security;"
}