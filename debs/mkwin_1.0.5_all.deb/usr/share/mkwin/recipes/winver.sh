# winver —— 关于 Windows（GTK4）
# https://github.com/DeepslateQAQ/linux-winver
pkg_name="winver"
pkg_desc="winver：弹出“Windows 版本”对话框（修复了非 KDE 桌面没有 winver 的 bug）"
pkg_url="https://github.com/DeepslateQAQ/linux-winver"
pkg_license="未注明"
pkg_category="gui"
pkg_tag="prank"
pkg_needs="cc make pkg-config glib-compile-resources"
pkg_deps_arch="gtk4"
pkg_deps_debian="libgtk-4-dev"
pkg_deps_fedora="gtk4-devel"

build() {
    make
}

package() {
    make install DESTDIR="$pkgdir" PREFIX="$MKWIN_PREFIX"
}
