# copilot-for-linux —— Windows Copilot 侧边栏
# https://github.com/macOS-Terminal/Copilot-For-Linux
pkg_name="copilot"
pkg_desc="Windows Copilot 风格独立应用窗口：UA 伪装成 Win11 Edge 打开 copilot.microsoft.com（Chromium --app 模式）"
pkg_url="https://github.com/macOS-Terminal/Copilot-For-Linux"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="practical"
pkg_needs=""
pkg_note="纯 shell 脚本无需编译；自动探测 chromium / google-chrome / microsoft-edge，--sidebar 侧边栏模式；无浏览器时可用项目自带的 fetch-chromium.sh 下载便携版 Chromium"

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/copilot"
    install -d "$d"
    install -m755 "$srcdir/copilot-for-linux.sh" "$d/copilot-for-linux.sh"
    inst_script copilot <<EOF
#!/bin/sh
exec "$MKWIN_PREFIX/share/mkwin/copilot/copilot-for-linux.sh" "\$@"
EOF
    inst_desktop copilot "Windows Copilot" \
        "$MKWIN_PREFIX/bin/copilot" copilot "Utility;AI;"
}