# regedit —— 把 /etc、~/.config、/boot 浏览成注册表树
# https://github.com/heyManNice/regedit
pkg_name="regedit"
pkg_desc="注册表编辑器：把 /etc、~/.config、/boot 等配置文件树当作注册表浏览"
pkg_url="https://github.com/heyManNice/regedit"
pkg_license="GPL-3.0"
pkg_category="gui"
pkg_tag="practical"
pkg_needs="cc meson ninja pkg-config"
pkg_deps_arch="gtk3 glib2 json-glib"
pkg_deps_debian="libgtk-3-dev libglib2.0-dev libjson-glib-dev"
pkg_deps_fedora="gtk3-devel glib2-devel json-glib-devel"

build() {
    meson setup build --prefix "$MKWIN_PREFIX" --buildtype release
    meson compile -C build
}

package() {
    DESTDIR="$pkgdir" meson install -C build
}
