# libschrodinger —— LD_PRELOAD 库：致命信号弹出 Windows 应用错误对话框
# https://github.com/LyCecilion/libschrodinger
pkg_name="libschrodinger"
pkg_desc="LD_PRELOAD 整活库：程序崩溃时弹出经典 Windows 应用错误对话框（可附加 gdb）"
pkg_url="https://github.com/LyCecilion/libschrodinger"
pkg_license="MIT"
pkg_category="system"
pkg_tag="prank"
pkg_needs="cc g++ make pkg-config"
pkg_deps_arch="qt6-base"
pkg_deps_debian="qt6-base-dev"
pkg_deps_fedora="qt6-qtbase-devel"
pkg_note="用法：LD_PRELOAD=$MKWIN_PREFIX/lib/libschrodinger.so <命令>；对话框与库同目录安装，不可分离"

build() {
    if ! make; then
        # 新版 binutils/GCC 链接 Qt6 protected 符号会报 copy relocation 错误，
        # 此时改用 clang++ 重试（其生成 GOT 引用，不受影响）
        command -v clang++ >/dev/null || {
            echo "libschrodinger：g++ 链接失败，且系统无 clang++ 可回退" >&2
            return 1
        }
        make clean
        make CXX=clang++
    fi
}

package() {
    # 对话框必须与 .so 同目录（库按自身路径查找 schrodinger-dialog）
    install -Dm755 "$srcdir/build/libschrodinger.so" \
        "$pkgdir$MKWIN_PREFIX/lib/libschrodinger.so"
    install -Dm755 "$srcdir/build/schrodinger-dialog" \
        "$pkgdir$MKWIN_PREFIX/lib/schrodinger-dialog"
}
