# sticky-keys —— Windows 粘滞键体验
# https://github.com/xusk1234/Linux-Sticky-keys
pkg_name="sticky-keys"
pkg_desc="Windows 粘滞键复刻：连按五次 Shift 开关、Ctrl+Shift+Q 退出（python-evdev 读键 + xdotool 发送按键）"
pkg_url="https://github.com/xusk1234/Linux-Sticky-keys"
pkg_license="MIT"
pkg_category="system"
pkg_tag="prank"
pkg_needs="python3"
pkg_deps_arch="python-evdev xdotool"
pkg_deps_debian="python3-evdev xdotool"
pkg_deps_fedora="python3-evdev xdotool"
pkg_note="需要 root 权限读取 /dev/input 设备，请用 sudo 运行；连按五次 Shift 启用/禁用，Ctrl+Shift+Q 退出"

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/sticky-keys"
    install -d "$d"
    install -m644 "$srcdir/Linux-Sticky-keys.py" "$d/"
    inst_script sticky-keys <<EOF
#!/bin/sh
exec python3 "$MKWIN_PREFIX/share/mkwin/sticky-keys/Linux-Sticky-keys.py" "\$@"
EOF
    inst_desktop sticky-keys "粘滞键" \
        "$MKWIN_PREFIX/bin/sticky-keys" input-keyboard "System;Utility;"
}