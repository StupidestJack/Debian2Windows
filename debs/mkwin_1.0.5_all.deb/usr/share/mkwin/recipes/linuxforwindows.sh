# linuxforwindows —— 离线把 PE(EXE) 可执行文件转成 ELF
# https://github.com/dyz131005/LinuxForWindows
pkg_name="linuxforwindows"
pkg_desc="离线 PE->ELF 转换器：文件格式层面把 Windows 可执行文件转成 Linux 可运行"
pkg_url="https://github.com/dyz131005/LinuxForWindows"
pkg_license="MIT"
pkg_category="lowlevel"
pkg_tag="practical"
pkg_needs="cc"

build() {
    if ! bash build.sh 64; then
        # 静态链接失败（缺 libc.a）时退回动态链接
        gcc -std=c11 -O2 -D_FILE_OFFSET_BITS=64 \
            -o LinuxForWindows_64 src/pe_to_elf.c || return 1
    fi
}

package() {
    inst_bin "$srcdir/LinuxForWindows_64" LinuxForWindows
}
