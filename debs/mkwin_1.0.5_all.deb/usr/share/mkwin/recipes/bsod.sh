# bsod —— 通过 DRM Master 直接渲染的蓝屏演示（带二维码）
# https://github.com/heyManNice/bsod
pkg_name="bsod"
pkg_desc="通过 DRM Master 直接渲染的 Windows 风格蓝屏，附二维码"
pkg_url="https://github.com/heyManNice/bsod"
pkg_license="MIT"
pkg_category="lowlevel"
pkg_tag="prank"
pkg_needs="cc meson ninja pkg-config"
pkg_deps_arch="libdrm freetype2 fontconfig systemd"
pkg_deps_debian="libdrm-dev libfreetype-dev libfontconfig-dev systemd-dev"
pkg_deps_fedora="libdrm-devel freetype-devel fontconfig-devel systemd-devel"
pkg_note="直接接管 DRM 输出，建议仅在 TTY 控制台下演示"

build() {
    meson setup build --prefix "$MKWIN_PREFIX" --buildtype release
    meson compile -C build
}

package() {
    DESTDIR="$pkgdir" meson install -C build
}
