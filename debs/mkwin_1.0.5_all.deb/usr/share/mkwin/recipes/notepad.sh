# notepad —— 复刻 Windows 记事本
# https://github.com/linux-user-114514/NotepadOnLinux
#
# 特别说明：上游仓库不含源码（作者 README 自述“手滑删掉了”），
# 仓库内只有一个预编译 ELF。本包是 mkwin 中唯一不经源码构建的特例。
pkg_name="notepad"
pkg_desc="Windows 记事本复刻（上游未提供源码，安装仓库内置的预编译二进制）"
pkg_url="https://github.com/linux-user-114514/NotepadOnLinux"
pkg_license="未注明"
pkg_category="gui"
pkg_tag="practical"
pkg_note="上游无源码可用，本包直接安装仓库内置的预编译 ELF"

package() {
    inst_bin "$srcdir/Notepad" Notepad
}
