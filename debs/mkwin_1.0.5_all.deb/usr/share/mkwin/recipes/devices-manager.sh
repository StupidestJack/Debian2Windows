# devices-manager —— 设备管理器（整活：只能看不能管）
# https://github.com/xusk1234/Linux-Devices-Manager
pkg_name="devices-manager"
pkg_desc="Windows 设备管理器复刻：列出硬件设备与属性（PyQt5，查看设备信息需要 root）"
pkg_url="https://github.com/xusk1234/Linux-Devices-Manager"
pkg_license="MIT"
pkg_category="gui"
pkg_tag="prank"
pkg_needs="python3"
pkg_deps_arch="python-pyqt5"
pkg_deps_debian="python3-pyqt5"
pkg_deps_fedora="python3-qt5"
pkg_note="读取 /sys 设备信息需要 root，请用 sudo 运行；纯 Python 无需编译"

package() {
    local d="$pkgdir$MKWIN_PREFIX/share/mkwin/devices-manager"
    install -d "$d"
    install -m644 "$srcdir/Linux Devices Manager.py" "$d/"
    inst_script devices-manager <<EOF
#!/bin/sh
exec python3 "$MKWIN_PREFIX/share/mkwin/devices-manager/Linux Devices Manager.py" "\$@"
EOF
    inst_desktop devices-manager "设备管理器" \
        "$MKWIN_PREFIX/bin/devices-manager" hardware "System;Settings;"
}