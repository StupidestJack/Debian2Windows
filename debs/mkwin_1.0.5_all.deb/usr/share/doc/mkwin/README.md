# mkwin

一键把 [awesome-windows-on-linux](https://github.com/windowix/awesome-windows-on-linux)
全家桶**从源码构建**并安装到 Linux 上的包管理器，操作风格仿 pacman。
自带一个 lazygit/pacseek 风格的深色多面板 TUI——**`mkwin -S` 不带参数即打开选择安装界面**。

```
用法：mkwin [选项] <操作> [软件包...]
  mkwin -S <pkg>...       从源码构建并安装指定软件包
  mkwin -S all            一键安装全部软件包（已装且最新则跳过）
  mkwin -Sy all           先刷新配方，再一键安装全部软件包
  mkwin -S                不带参数：打开 TUI 选择安装界面
  mkwin -Rns [<pkg>...]    卸载全部（或指定）已安装软件包
  mkwin -Ss <关键词>        搜索仓库
  mkwin -Si <pkg>          查看软件包信息
  mkwin -Q | -Qq | -Qi     列出已安装的软件包
  mkwin -L | -L --raw      列出仓库中的全部软件包（--raw 供脚本/TUI 解析）
  mkwin -Sc                清理源码与构建缓存
  mkwin-tui                启动 TUI 安装界面（等价于 mkwin -S）

通用选项：
  --noconfirm              跳过确认提示（TUI 调用 mkwin 时默认携带）
  --prefix <路径>          安装前缀（默认 /usr/local，或用 MKWIN_PREFIX 环境变量）
```

## 快速开始

```bash
git clone https://github.com/<you>/mkwin && cd mkwin
sudo make install            # 安装 mkwin 本体（也可直接 ./mkwin 使用）

mkwin -S                     # 打开 TUI，空格勾选，Enter 安装
mkwin -Ss explorer           # 搜一下
sudo mkwin -S cmd explorer   # 从源码构建安装（explorer 为 xbodwf 版）
mkwin -Q                     # 看看装了什么
sudo mkwin -Rns              # 一键全部卸载
```

## TUI（`mkwin -S` / `mkwin-tui`）

深色多面板界面：左侧按分类分组的软件包列表（勾选框 + 整活/实用标签 + 已装 ✓），
右侧实时显示选中包的详情（描述 / 上游 / 许可 / 构建工具 / 依赖 / 备注），底部是状态行与快捷键栏。

| 按键 | 作用 |
|---|---|
| `↑` `↓` / `j` `k` | 移动光标（自动跳过分类标题行） |
| `PgUp` / `PgDn` | 翻页 |
| `空格` | 勾选 / 取消勾选当前包 |
| `a` / `n` | 全选 / 清空勾选 |
| `/` | 进入过滤模式（输入即按名称+描述过滤；`Enter` 保留结果，`Esc` 取消并清空） |
| `Enter` / `i` | 安装勾选的包（未勾选则安装光标所在包） |
| `d` | 卸载勾选的（已安装）包 |
| `u` | 一键安装/升级全部（等价 `mkwin -S all`） |
| `r` | 刷新已安装状态 |
| `q` | 退出（`Ctrl+C` 亦可） |
| 鼠标 | 点击包行选中、点击 `[ ]` 勾选、滚轮滚动、点击底部搜索框聚焦搜索 |

执行安装/卸载时会临时切回普通屏幕运行 `mkwin`，结束后按任意键返回 TUI。
搜索框内输入即按「名称 + 描述」实时过滤；`Enter` 保留过滤结果，`Esc` 取消并清空。

## 软件包一览（36 个）

| 包名 | 分类 | 说明 |
|---|---|---|
| `cmd` | CLI | 纯 C89 手写的 cmd.exe 克隆 |
| `aptx` | CLI | apt 包装器，装完推荐“捆绑软件”（仅 Debian 系可用） |
| `windowshit` | CLI | Rust 重写的 ipconfig/tasklist 等 24 个 Windows 命令 |
| `powershell-linux` | CLI | PowerShell 风格解释器：对象管道、114 个内置 cmdlet、.ps1 脚本（纯 Go，零依赖） |
| `winget` | CLI | winget CLI 整活移植：把 winget install/search 翻译成系统包管理器命令（Rust） |
| `activate-linux` | GUI | 桌面“激活 Linux”水印（Wayland/X11） |
| `explorer` | GUI | **Win11 风格文件管理器（xbodwf/explorer-for-linux，Electron+Vue）** |
| `explorer-prank` | GUI | 文件管理器整活版（含“未响应”恶搞），与 `explorer` 冲突 |
| `notepad` | GUI | Windows 记事本复刻（上游无源码，装的是仓库内置预编译 ELF） |
| `regedit` | GUI | 把 /etc、~/.config、/boot 当注册表浏览 |
| `runbox` | GUI | Win+R 运行对话框（GTK4/libadwaita） |
| `mmclinux` | GUI | tkinter 复刻 MMC 管理控制台 |
| `openconsole` | GUI | 微软 OpenConsole 引擎 Linux 移植（Qt6） |
| `sas` | GUI | Win11 Ctrl+Alt+Delete 安全屏幕（Qt6） |
| `winsat` | GUI | Windows 体验指数移植（Python，装进独立 venv） |
| `windowssearch` | GUI | 任务栏搜索复刻（你搜的不是你想搜的） |
| `lindows-control` | GUI | Windows 风格控制面板（egui） |
| `animated-plasma-task` | GUI | KDE Plasma 6 任务栏动画（固定装到 `/usr`） |
| `winver` | GUI | winver“关于 Windows”对话框（GTK4） |
| `devices-manager` | GUI | 设备管理器复刻：列出硬件与属性（PyQt5，查看需 root） |
| `linux-autofix` | GUI | 启动修复整活：扫完建议你“恢复到 Ubuntu 默认设置” |
| `linuxdefender` | GUI | Windows 安全中心整活：一个不知道有啥用的“杀毒软件” |
| `lindows-troubleshooting` | GUI | 疑难解答整活：开始检测后请等待，浪费你人生中宝贵的一分钟 |
| `widget-panel` | GUI | Win11 小组件面板：右侧滑入，新闻/天气/时钟（PyQt5） |
| `taskschd` | GUI | 任务计划程序克隆：管理 cron/systemd timer（PySide6） |
| `msconfig` | GUI | Windows msconfig 移植：启动项/服务/引导/内核参数（C++/Qt6） |
| `copilot` | GUI | Windows Copilot 风格独立窗口（Chromium --app 模式，UA 伪装 Win11 Edge） |
| `linux-uac` | 系统 | PAM 模块：sudo 弹 UAC（默认不自动改 /etc/pam.d） |
| `libobscure` | 系统 | LD_PRELOAD：报错换成 0x8007xxxx 错误码 |
| `libschrodinger` | 系统 | LD_PRELOAD：崩溃弹 Windows 应用错误对话框 |
| `adpop` | 系统 | 广告弹窗轰炸服务 |
| `sticky-keys` | 系统 | Windows 粘滞键整活：连按五次 Shift 开关（python-evdev，需 root） |
| `bsod` | 底层 | DRM 直渲染蓝屏（带二维码） |
| `winupdate` | 底层 | 假更新：50% 真重启更新、50% 蓝屏 |
| `linuxforwindows` | 底层 | PE(EXE) → ELF 离线转换器 |
| `lsw` | 底层 | Linux Subsystem for Windows：在 Linux 上直接运行 .exe（需 wine） |

## 依赖

- mkwin 本体：bash ≥ 4.4、git、coreutils（零外部依赖，TUI 也是纯 bash + ANSI 实现）
- 各软件包按配方声明构建依赖（`mkwin -Si <pkg>` 可查）。缺依赖时 mkwin 会给出提示，
  在 Arch / Debian / Fedora 三系上可以一键用系统包管理器补装。
- 特例：`libschrodinger` 在过新工具链（如 GCC 16）上 g++ 链接 Qt6 会失败，配方会自动改用 clang++ 重试。

## 工作原理

- 每个软件包对应 `recipes/<包名>.sh` 配方：声明元数据（描述 / 上游 / 依赖 / 冲突）与
  `build()`、`package()` 两个函数；`package()` 把产物装入 `$pkgdir` 暂存区。
- 安装流程：`git clone --depth 1` 上游 → 在干净副本中 `build()` → `package()` 暂存 →
  逐文件冲突检查（被覆盖的系统文件先备份）→ 合并进根文件系统并按清单校验 →
  在 `/var/lib/mkwin/db/<包名>/` 记录文件清单与上游 commit。
- 卸载按清单删文件、**还原当初备份的系统文件**、清理空目录。
- `-S all` 对比配方哈希与上游 commit，仅变化时重建；与已装 `explorer` 冲突的
  `explorer-prank` 会自动跳过。
- 少数包声明 `pkg_prefix="/usr"`（`animated-plasma-task`、`lsw`），因为 KDE 组件扫描路径
  与 binfmt_misc 注册路径必须是系统目录；当你自定义 `MKWIN_PREFIX` 时会尊重你的前缀。

### 写一个新配方

```bash
pkg_name="hello"
pkg_desc="示例：Hello World"
pkg_url="https://github.com/user/hello"
pkg_license="MIT"
pkg_category="cli"          # cli / gui / system / lowlevel
pkg_tag="practical"         # practical / prank
pkg_needs="cc make"         # 构建所需命令（command -v 检查）
pkg_deps_arch="gtk3"        # 可选：按发行版声明系统依赖
pkg_deps_debian="libgtk-3-dev"

build()   { make; }
package() { inst_bin "$srcdir/hello" hello; }   # 一切装入 "$pkgdir"
```

可用的安装辅助：`inst_bin <源> <名>`（装进前缀 bin）、`inst_script <名>`（从 stdin 读
wrapper 脚本）、`inst_desktop <文件名> <名称> <Exec> <图标> <类别>`；可选钩子
`post_install()` / `pre_remove()`。

## 安全须知

- 仓库里一半是**整活项目**（`pkg_tag=prank`）：蓝屏会接管 DRM、`winupdate` 有 50% 概率
  真的重启、`lsw`/`linux-uac` 涉及 binfmt_misc 与 PAM。mkwin 对这类侵入式配置的策略是
  **只装文件、不自动激活**——启用方法在安装结束的备注里给出。请在虚拟机里整活，
  别在生产机上 `-S all`。
- 构建以 root 身份进行（与 pacman 模型一致），源码来自各上游仓库。
- `notepad` 是唯一例外：上游没有源码（作者自述误删），只能安装其仓库自带的预编译二进制。

## 环境变量

| 变量 | 默认 | 说明 |
|---|---|---|
| `MKWIN_PREFIX` | `/usr/local` | 安装前缀 |
| `MKWIN_DB` | `/var/lib/mkwin/db` | 包数据库（清单/元数据/备份） |
| `MKWIN_CACHE` | `/var/cache/mkwin` | 源码克隆与构建目录 |
| `MKWIN_NO_SUDO` | 空 | 设为 1 禁止自动 sudo（沙箱测试用） |

## 许可

MIT（见 LICENSE）。各软件包遵循其上游自身许可。
