#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import threading
import os
import json
import locale
from pathlib import Path

class LanguageManager:
    """語言管理類別"""
    def __init__(self):
        self.lang_dir = Path(__file__).parent / "lang"
        self.lang_dir.mkdir(exist_ok=True)
        # 初始化 locale 設定為使用者環境
        self.current_lang = None
        try:
            locale.setlocale(locale.LC_ALL, '')
            self.current_lang = locale.getlocale()[0]
        except:
            env_lang = os.environ.get('LANG', '').split('.')[0]
            if env_lang:
                self.current_lang = env_lang

        self.strings = {}
        
        # 建立預設語言檔案
        self._create_default_lang_files()
        
        # 載入語言
        self.load_language(self.current_lang)
    
    def _create_default_lang_files(self):
        """建立預設語言檔案"""
        # 繁體中文
        zh_tw = {
            "app_title": "Services",
            "properties_title": "{} 內容 (本機電腦)",
            "tab_general": "一般",
            "tab_login": "登入",
            "tab_recovery": "復原",
            "tab_dependencies": "相依性",
            "label_service_name": "服務名稱:",
            "label_display_name": "顯示名稱:",
            "label_description": "描述:",
            "label_executable_path": "可執行檔所在路徑:",
            "label_startup_type": "啟動類型(E):",
            "label_service_status": "服務狀態:",
            "label_startup_params": "啟動參數(M):",
            "label_startup_params_desc": "您可以在這裡指定啟動服務時所要套用的參數。",
            "btn_apply": "套用(A)",
            "btn_cancel": "取消",
            "btn_ok": "確定",
            "btn_start": "啟動(S)",
            "btn_stop": "停止(T)",
            "btn_pause": "暫停(P)",
            "btn_resume": "繼續(R)",
            "combo_auto_delayed": "自動 (延遲啟動)",
            "combo_auto": "自動",
            "combo_manual": "手動",
            "combo_disabled": "已停用",
            "status_running": "執行中",
            "status_stopped": "已停止",
            "status_failed": "失敗",
            "status_starting": "啟動中",
            "status_stopping": "停止中",
            "status_exited": "已結束",
            "status_unknown": "未知",
            "status_loading": "載入中...",
            "status_ready": "就緒",
            "status_loading_services": "載入服務清單...",
            "status_loaded": "已載入 {} 個服務",
            "status_loading_progress": "載入中... {}/{}",
            "status_starting_service": "正在啟動服務 {}...",
            "status_stopping_service": "正在停止服務 {}...",
            "status_restarting_service": "正在重新啟動服務 {}...",
            "menu_file": "檔案",
            "menu_exit": "離開",
            "menu_action": "動作",
            "menu_action_start": "啟動",
            "menu_action_stop": "停止",
            "menu_action_restart": "重新啟動",
            "menu_action_enable": "啟用",
            "menu_action_disable": "停用",
            "menu_action_mask": "遮罩",
            "menu_action_unmask": "取消遮罩",
            "menu_action_properties": "屬性",
            "menu_action_refresh": "重新整理",
            "menu_view": "檢視",
            "menu_view_all": "顯示所有服務",
            "menu_view_running": "顯示執行中的服務",
            "menu_view_stopped": "顯示已停止的服務",
            "menu_help": "說明",
            "menu_about": "關於",
            "tooltip_refresh": "重新整理",
            "tooltip_start": "啟動",
            "tooltip_stop": "停止",
            "tooltip_restart": "重新啟動",
            "tooltip_enable": "啟用",
            "tooltip_disable": "停用",
            "tooltip_mask": "遮罩",
            "tooltip_unmask": "取消遮罩",
            "tooltip_properties": "屬性",
            "label_search": "搜尋:",
            "label_services": "服務",
            "column_name": "名稱",
            "column_description": "描述",
            "column_status": "狀態",
            "column_startup_type": "啟動類型",
            "tab_logs": "服務日誌",
            "detail_select_service": "選取一個服務",
            "service_info": "服務資訊",
            "service_info_status": "狀態: {}",
            "service_info_startup": "啟動類型: {}",
            "service_info_file": "檔案: {}",
            "description_label": "描述",
            "total_services": "總計: {} 個服務",
            "confirm_action": "確認動作",
            "confirm_action_msg": "確定要對服務 '{}' 執行 {} 嗎？",
            "success_title": "成功",
            "success_msg": "服務 {} 執行成功",
            "error_title": "錯誤",
            "error_msg": "服務 {} 失敗:\n{}",
            "startup_changed": "啟動類型已變更",
            "service_details": "服務詳細資訊 - {}",
            "service_details_text": """Service: {}

狀態: {}
啟動類型: {}
載入狀態: {}
活動狀態: {}
子狀態: {}
主程序 PID: {}
記憶體: {}
服務檔案: {}

描述:
{}""",
            "about_title": "關於",
            "about_text": """Service Manager for Linux

用於管理 systemd 服務的圖形化工具。

功能：
- 啟動/停止/重新啟動服務
- 啟用/停用服務
- 遮罩/取消遮罩服務
- 檢視服務狀態和描述
- 搜尋和過濾服務
- 雙擊檢視服務屬性

需求：Linux 系統搭配 systemd
建議：使用 sudo 執行以獲得完整功能

版本：1.0""",
            "warning_select_service": "請先選取一個服務",
            "error_unknown": "未知",
            "error_no_description": "無描述",
            "error_path_unknown": "無法取得路徑",
            "confirm_stop": "確定要停止服務 {} 嗎？",
            "start_success": "服務 {} 已啟動",
            "start_failed": "啟動失敗",
            "stop_success": "服務 {} 已停止",
            "stop_failed": "停止失敗",
            "property_apply_disabled": "此功能未實作"
        }
        
        # 英文
        en = {
            "app_title": "Services",
            "properties_title": "{} Properties (Local Computer)",
            "tab_general": "General",
            "tab_login": "Log On",
            "tab_recovery": "Recovery",
            "tab_dependencies": "Dependencies",
            "label_service_name": "Service Name:",
            "label_display_name": "Display Name:",
            "label_description": "Description:",
            "label_executable_path": "Path to executable:",
            "label_startup_type": "Startup Type:",
            "label_service_status": "Service Status:",
            "label_startup_params": "Startup Parameters:",
            "label_startup_params_desc": "You can specify startup parameters for the service here.",
            "btn_apply": "Apply",
            "btn_cancel": "Cancel",
            "btn_ok": "OK",
            "btn_start": "Start",
            "btn_stop": "Stop",
            "btn_pause": "Pause",
            "btn_resume": "Resume",
            "combo_auto_delayed": "Automatic (Delayed Start)",
            "combo_auto": "Automatic",
            "combo_manual": "Manual",
            "combo_disabled": "Disabled",
            "status_running": "Running",
            "status_stopped": "Stopped",
            "status_failed": "Failed",
            "status_starting": "Starting",
            "status_stopping": "Stopping",
            "status_exited": "Exited",
            "status_unknown": "Unknown",
            "status_loading": "Loading...",
            "status_ready": "Ready",
            "status_loading_services": "Loading services...",
            "status_loaded": "Loaded {} services",
            "status_loading_progress": "Loading... {}/{}",
            "status_starting_service": "Starting service {}...",
            "status_stopping_service": "Stopping service {}...",
            "status_restarting_service": "Restarting service {}...",
            "menu_file": "File",
            "menu_exit": "Exit",
            "menu_action": "Action",
            "menu_action_start": "Start",
            "menu_action_stop": "Stop",
            "menu_action_restart": "Restart",
            "menu_action_enable": "Enable",
            "menu_action_disable": "Disable",
            "menu_action_mask": "Mask",
            "menu_action_unmask": "Unmask",
            "menu_action_properties": "Properties",
            "menu_action_refresh": "Refresh",
            "menu_view": "View",
            "menu_view_all": "Show All Services",
            "menu_view_running": "Show Running Services",
            "menu_view_stopped": "Show Stopped Services",
            "menu_help": "Help",
            "menu_about": "About",
            "tooltip_refresh": "Refresh",
            "tooltip_start": "Start",
            "tooltip_stop": "Stop",
            "tooltip_restart": "Restart",
            "tooltip_enable": "Enable",
            "tooltip_disable": "Disable",
            "tooltip_mask": "Mask",
            "tooltip_unmask": "Unmask",
            "tooltip_properties": "Properties",
            "label_search": "Search:",
            "label_services": "Services",
            "column_name": "Name",
            "column_description": "Description",
            "column_status": "Status",
            "column_startup_type": "Startup Type",
            "tab_logs": "Service Logs",
            "detail_select_service": "Select a service",
            "service_info": "Service Information",
            "service_info_status": "Status: {}",
            "service_info_startup": "Startup Type: {}",
            "service_info_file": "File: {}",
            "description_label": "Description",
            "total_services": "Total: {} services",
            "confirm_action": "Confirm Action",
            "confirm_action_msg": "Are you sure you want to {} service '{}'?",
            "success_title": "Success",
            "success_msg": "Service {} completed successfully",
            "error_title": "Error",
            "error_msg": "Failed to {} service:\n{}",
            "startup_changed": "Startup type changed",
            "service_details": "Service Details - {}",
            "service_details_text": """Service: {}

Status: {}
Startup Type: {}
Load State: {}
Active State: {}
Sub State: {}
Main PID: {}
Memory: {}
Service File: {}

Description:
{}""",
            "about_title": "About",
            "about_text": """Service Manager for Linux

A GUI tool for managing systemd services.

Features:
- Start/Stop/Restart services
- Enable/Disable services
- Mask/Unmask services
- View service status and description
- Search and filter services
- Double-click to view service properties

Requires: Linux with systemd
Recommended: Run with sudo for full functionality

Version: 1.0""",
            "warning_select_service": "Please select a service first",
            "error_unknown": "Unknown",
            "error_no_description": "No description",
            "error_path_unknown": "Unable to get path",
            "confirm_stop": "Are you sure you want to stop service {}?",
            "start_success": "Service {} started",
            "start_failed": "Start failed",
            "stop_success": "Service {} stopped",
            "stop_failed": "Stop failed",
            "property_apply_disabled": "This feature is not implemented"
        }
        
        # 寫入檔案
        zh_path = self.lang_dir / "zh_TW.json"
        en_path = self.lang_dir / "en.json"
        
        if not zh_path.exists():
            with open(zh_path, 'w', encoding='utf-8') as f:
                json.dump(zh_tw, f, ensure_ascii=False, indent=2)
        
        if not en_path.exists():
            with open(en_path, 'w', encoding='utf-8') as f:
                json.dump(en, f, ensure_ascii=False, indent=2)
    
    def load_language(self, lang_code):
        """載入語言（修復遞迴 Bug 版）"""
        if not lang_code:
            lang_code = "en"

        # 整理語系代碼（例如：zh_TW -> zh_TW，en_US -> en）
        target_file = self.lang_dir / f"{lang_code}.json"
        
        # 1. 精準匹配 (例如: zh_TW.json)
        if target_file.exists():
            try:
                with open(target_file, 'r', encoding='utf-8') as f:
                    self.strings = json.load(f)
                return
            except Exception as e:
                print(f"載入 {lang_code}.json 失敗: {e}")

        # 2. 降級匹配前綴 (例如: en_US -> en.json, zh_CN -> zh.json)
        short_code = lang_code.split('_')[0]
        short_file = self.lang_dir / f"{short_code}.json"
        if short_file.exists():
            try:
                with open(short_file, 'r', encoding='utf-8') as f:
                    self.strings = json.load(f)
                return
            except Exception as e:
                print(f"載入 {short_code}.json 失敗: {e}")

        # 3. 預設讀取 en.json，若都不存在則空字典（不使用遞迴）
        default_file = self.lang_dir / "en.json"
        if default_file.exists():
            try:
                with open(default_file, 'r', encoding='utf-8') as f:
                    self.strings = json.load(f)
            except Exception as e:
                print(f"載入預設 en.json 失敗: {e}")
                self.strings = {}
        else:
            self.strings = {}
    
    def get(self, key, default=None):
        """取得字串"""
        return self.strings.get(key, default or key)
    
    def get_languages(self):
        """取得所有可用的語言"""
        languages = []
        for file in self.lang_dir.glob("*.json"):
            lang_code = file.stem
            languages.append(lang_code)
        return languages


class ServicePropertiesDialog:
    """服務屬性對話框"""
    def __init__(self, parent, service_name, service_info, lang_manager):
        self.parent = parent
        self.service_name = service_name
        self.service_info = service_info
        self.lang = lang_manager
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title(self.lang.get("properties_title").format(service_name))
        self.dialog.geometry("450x580")
        self.dialog.resizable(False, False)
        
        self.dialog.transient(parent)
        
        self._create_widgets()
        self._load_service_data()
        
        self.dialog.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - self.dialog.winfo_width()) // 2
        y = parent.winfo_y() + (parent.winfo_height() - self.dialog.winfo_height()) // 2
        self.dialog.geometry(f"+{x}+{y}")
        
        self.dialog.after(10, self._set_grab)

    def _set_grab(self):
        try:
            self.dialog.grab_set()
        except:
            pass

    def _create_widgets(self):
        notebook = ttk.Notebook(self.dialog)
        notebook.pack(fill=tk.BOTH, expand=True, padx=8, pady=(8, 0))

        self.tab_general = ttk.Frame(notebook, padding=12)
        notebook.add(self.tab_general, text=self.lang.get("tab_general"))
        notebook.add(ttk.Frame(notebook), text=self.lang.get("tab_login"))
        notebook.add(ttk.Frame(notebook), text=self.lang.get("tab_recovery"))
        notebook.add(ttk.Frame(notebook), text=self.lang.get("tab_dependencies"))

        self._create_general_tab()
        
        bottom_frame = ttk.Frame(self.dialog, padding=(8, 8))
        bottom_frame.pack(side=tk.BOTTOM, fill=tk.X)

        ttk.Button(
            bottom_frame,
            text=self.lang.get("btn_apply"),
            width=8,
            state="disabled",
        ).pack(side=tk.RIGHT, padx=(4, 0))
        ttk.Button(bottom_frame, text=self.lang.get("btn_cancel"), width=8, 
                  command=self.dialog.destroy).pack(side=tk.RIGHT, padx=4)
        ttk.Button(bottom_frame, text=self.lang.get("btn_ok"), width=8, 
                  command=self.dialog.destroy).pack(side=tk.RIGHT, padx=4)

    def _create_general_tab(self):
        tab = self.tab_general
        
        ttk.Label(tab, text=self.lang.get("label_service_name")).grid(
            row=0, column=0, sticky="w", pady=4
        )
        self.entry_service_name = ttk.Entry(tab)
        self.entry_service_name.grid(row=0, column=1, columnspan=2, sticky="ew", pady=4)

        ttk.Label(tab, text=self.lang.get("label_display_name")).grid(
            row=1, column=0, sticky="w", pady=4
        )
        self.entry_display_name = ttk.Entry(tab)
        self.entry_display_name.grid(row=1, column=1, columnspan=2, sticky="ew", pady=4)

        ttk.Label(tab, text=self.lang.get("label_description")).grid(
            row=2, column=0, sticky="nw", pady=4
        )
        self.text_desc = tk.Text(tab, height=4, width=30, font=("Microsoft JhengHei", 9), wrap=tk.WORD)
        self.text_desc.grid(row=2, column=1, columnspan=2, sticky="ew", pady=4)

        ttk.Label(tab, text=self.lang.get("label_executable_path")).grid(
            row=3, column=0, columnspan=3, sticky="w", pady=(8, 2)
        )
        self.lbl_path = ttk.Label(tab, text="", wraplength=350)
        self.lbl_path.grid(row=4, column=0, columnspan=3, sticky="w", pady=(0, 8))

        ttk.Label(tab, text=self.lang.get("label_startup_type")).grid(
            row=5, column=0, sticky="w", pady=4
        )
        self.combo_startup = ttk.Combobox(
            tab,
            values=[
                self.lang.get("combo_auto_delayed"),
                self.lang.get("combo_auto"),
                self.lang.get("combo_manual"),
                self.lang.get("combo_disabled"),
            ],
            state="readonly",
        )
        self.combo_startup.grid(row=5, column=1, columnspan=2, sticky="ew", pady=4)
        self.combo_startup.bind('<<ComboboxSelected>>', self._on_startup_changed)

        ttk.Separator(tab, orient="horizontal").grid(
            row=6, column=0, columnspan=3, sticky="ew", pady=12
        )

        ttk.Label(tab, text=self.lang.get("label_service_status")).grid(
            row=7, column=0, sticky="w", pady=4
        )
        self.lbl_status = ttk.Label(tab, text="", font=("Microsoft JhengHei", 9, "bold"))
        self.lbl_status.grid(row=7, column=1, sticky="w", pady=4)

        btn_frame = ttk.Frame(tab)
        btn_frame.grid(row=8, column=0, columnspan=3, sticky="ew", pady=6)

        self.btn_start = ttk.Button(btn_frame, text=self.lang.get("btn_start"), width=8)
        self.btn_start.pack(side=tk.LEFT, padx=(0, 2))
        
        self.btn_stop = ttk.Button(btn_frame, text=self.lang.get("btn_stop"), width=8, state="disabled")
        self.btn_stop.pack(side=tk.LEFT, padx=2)
        
        self.btn_pause = ttk.Button(btn_frame, text=self.lang.get("btn_pause"), width=8, state="disabled")
        self.btn_pause.pack(side=tk.LEFT, padx=2)
        
        self.btn_resume = ttk.Button(btn_frame, text=self.lang.get("btn_resume"), width=8, state="disabled")
        self.btn_resume.pack(side=tk.LEFT, padx=(2, 0))

        ttk.Label(tab, text=self.lang.get("label_startup_params_desc")).grid(
            row=9, column=0, columnspan=3, sticky="w", pady=(10, 4)
        )

        ttk.Label(tab, text=self.lang.get("label_startup_params")).grid(
            row=10, column=0, sticky="w", pady=4
        )
        ttk.Entry(tab).grid(row=10, column=1, columnspan=2, sticky="ew", pady=4)

        tab.columnconfigure(1, weight=1)
        
        self.btn_start.config(command=self._on_start)
        self.btn_stop.config(command=self._on_stop)

    def _load_service_data(self):
        status, description, startup = self.service_info
        
        self.entry_service_name.insert(0, self.service_name)
        self.entry_service_name.config(state='readonly')
        
        display_name = self.service_name.replace('.service', '').replace('_', ' ')
        self.entry_display_name.insert(0, display_name)
        self.entry_display_name.config(state='readonly')
        
        self.text_desc.insert("1.0", description if description else self.lang.get("error_no_description"))
        self.text_desc.config(state='disabled')
        
        status_text = {
            "Running": self.lang.get("status_running"),
            "Stopped": self.lang.get("status_stopped"),
            "Failed": self.lang.get("status_failed"),
            "Starting": self.lang.get("status_starting"),
            "Stopping": self.lang.get("status_stopping"),
            "Exited": self.lang.get("status_exited"),
            "Unknown": self.lang.get("status_unknown")
        }.get(status, status)
        
        self.lbl_status.config(text=status_text)
        
        if status == "Running":
            self.lbl_status.config(foreground='green')
        elif status == "Stopped":
            self.lbl_status.config(foreground='gray')
        elif status == "Failed":
            self.lbl_status.config(foreground='red')
        
        startup_map = {
            "Enabled": self.lang.get("combo_auto"),
            "Disabled": self.lang.get("combo_disabled"),
            "Masked": self.lang.get("combo_disabled"),
            "Static": self.lang.get("combo_manual"),
            "Indirect": self.lang.get("combo_manual"),
            "Automatic": self.lang.get("combo_auto")
        }
        startup_display = startup_map.get(startup, self.lang.get("combo_manual"))
        self.combo_startup.set(startup_display)
        
        try:
            stdout, stderr, code = self._run_command(f"systemctl show {self.service_name} -p FragmentPath")
            if code == 0 and stdout:
                path = stdout.split('=', 1)[1].strip()
                self.lbl_path.config(text=path)
            else:
                self.lbl_path.config(text=self.lang.get("error_path_unknown"))
        except:
            self.lbl_path.config(text=self.lang.get("error_path_unknown"))
        
        self._update_buttons(status)

    def _update_buttons(self, status):
        if status == "Running":
            self.btn_start.config(state="disabled")
            self.btn_stop.config(state="normal")
        elif status in ["Stopped", "Exited"]:
            self.btn_start.config(state="normal")
            self.btn_stop.config(state="disabled")
        else:
            self.btn_start.config(state="disabled")
            self.btn_stop.config(state="disabled")

    def _on_startup_changed(self, event):
        messagebox.showinfo(self.lang.get("startup_changed"), 
                           self.lang.get("startup_changed"))

    def _on_start(self):
        self.btn_start.config(state="disabled")
        self.lbl_status.config(text=self.lang.get("status_starting"))
        self.lbl_status.config(foreground='blue')
        
        def start_thread():
            stdout, stderr, code = self._run_command(f"sudo systemctl start {self.service_name}")
            if code == 0:
                self.dialog.after(0, lambda: self.lbl_status.config(
                    text=self.lang.get("status_running"), foreground='green'))
                self.dialog.after(0, lambda: self._update_buttons("Running"))
                self.dialog.after(0, lambda: messagebox.showinfo(
                    self.lang.get("success_title"), 
                    self.lang.get("start_success").format(self.service_name)))
            else:
                self.dialog.after(0, lambda: self.lbl_status.config(
                    text=self.lang.get("start_failed"), foreground='red'))
                self.dialog.after(0, lambda: self.btn_start.config(state="normal"))
                self.dialog.after(0, lambda: messagebox.showerror(
                    self.lang.get("error_title"), 
                    self.lang.get("error_msg").format(self.lang.get("btn_start"), stderr)))
        
        threading.Thread(target=start_thread, daemon=True).start()

    def _on_stop(self):
        if not messagebox.askyesno(self.lang.get("confirm_action"), 
                                   self.lang.get("confirm_stop").format(self.service_name)):
            return
        
        self.btn_stop.config(state="disabled")
        self.lbl_status.config(text=self.lang.get("status_stopping"))
        self.lbl_status.config(foreground='blue')
        
        def stop_thread():
            stdout, stderr, code = self._run_command(f"sudo systemctl stop {self.service_name}")
            if code == 0:
                self.dialog.after(0, lambda: self.lbl_status.config(
                    text=self.lang.get("status_stopped"), foreground='gray'))
                self.dialog.after(0, lambda: self._update_buttons("Stopped"))
                self.dialog.after(0, lambda: messagebox.showinfo(
                    self.lang.get("success_title"), 
                    self.lang.get("stop_success").format(self.service_name)))
            else:
                self.dialog.after(0, lambda: self.lbl_status.config(
                    text=self.lang.get("stop_failed"), foreground='red'))
                self.dialog.after(0, lambda: self.btn_stop.config(state="normal"))
                self.dialog.after(0, lambda: messagebox.showerror(
                    self.lang.get("error_title"), 
                    self.lang.get("error_msg").format(self.lang.get("btn_stop"), stderr)))
        
        threading.Thread(target=stop_thread, daemon=True).start()

    def _run_command(self, command):
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
            return result.stdout.strip(), result.stderr.strip(), result.returncode
        except Exception as e:
            return "", str(e), 1


class ServicesApp:
    def __init__(self, root):
        self.root = root
        self.lang = LanguageManager()
        
        self.root.title(self.lang.get("app_title"))
        self.root.geometry("1100x700")
        
        self.all_services = []
        self.current_service = None

        self._create_menu()
        self._create_toolbar()
        self._create_main_layout()
        
        self.refresh_services()

    def _create_menu(self):
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label=self.lang.get("menu_exit"), command=self.root.quit)
        menubar.add_cascade(label=self.lang.get("menu_file"), menu=file_menu)

        action_menu = tk.Menu(menubar, tearoff=0)
        action_menu.add_command(label=self.lang.get("menu_action_start"), command=self.start_service)
        action_menu.add_command(label=self.lang.get("menu_action_stop"), command=self.stop_service)
        action_menu.add_command(label=self.lang.get("menu_action_restart"), command=self.restart_service)
        action_menu.add_separator()
        action_menu.add_command(label=self.lang.get("menu_action_enable"), command=self.enable_service)
        action_menu.add_command(label=self.lang.get("menu_action_disable"), command=self.disable_service)
        action_menu.add_command(label=self.lang.get("menu_action_mask"), command=self.mask_service)
        action_menu.add_command(label=self.lang.get("menu_action_unmask"), command=self.unmask_service)
        action_menu.add_separator()
        action_menu.add_command(label=self.lang.get("menu_action_properties"), command=self.show_properties)
        action_menu.add_command(label=self.lang.get("menu_action_refresh"), command=self.refresh_services)
        menubar.add_cascade(label=self.lang.get("menu_action"), menu=action_menu)

        view_menu = tk.Menu(menubar, tearoff=0)
        view_menu.add_command(label=self.lang.get("menu_view_all"))
        view_menu.add_command(label=self.lang.get("menu_view_running"))
        view_menu.add_command(label=self.lang.get("menu_view_stopped"))
        menubar.add_cascade(label=self.lang.get("menu_view"), menu=view_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label=self.lang.get("menu_about"), command=self.show_about)
        menubar.add_cascade(label=self.lang.get("menu_help"), menu=help_menu)

        self.root.config(menu=menubar)

    def _create_toolbar(self):
        toolbar = ttk.Frame(self.root, padding=(2, 2))
        toolbar.pack(side=tk.TOP, fill=tk.X)

        btn_specs = [
            ("🔄", self.lang.get("tooltip_refresh"), self.refresh_services),
            ("▶️", self.lang.get("tooltip_start"), self.start_service),
            ("⬛", self.lang.get("tooltip_stop"), self.stop_service),
            ("⏸️", self.lang.get("tooltip_restart"), self.restart_service),
            ("✓", self.lang.get("tooltip_enable"), self.enable_service),
            ("✗", self.lang.get("tooltip_disable"), self.disable_service),
            ("🔒", self.lang.get("tooltip_mask"), self.mask_service),
            ("🔓", self.lang.get("tooltip_unmask"), self.unmask_service),
            ("📋", self.lang.get("tooltip_properties"), self.show_properties),
        ]
        
        for symbol, tooltip, command in btn_specs:
            btn = ttk.Button(toolbar, text=symbol, width=3, command=command)
            btn.pack(side=tk.LEFT, padx=1)
            self._create_tooltip(btn, tooltip)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, padx=5, fill=tk.Y)
        ttk.Label(toolbar, text=self.lang.get("label_search")).pack(side=tk.LEFT, padx=(10, 5))
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self.filter_services())
        search_entry = ttk.Entry(toolbar, textvariable=self.search_var, width=25)
        search_entry.pack(side=tk.LEFT, padx=5)

    def _create_tooltip(self, widget, text):
        def show_tooltip(event):
            tooltip = tk.Toplevel(widget)
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")
            label = tk.Label(tooltip, text=text, background="#ffffe0", relief="solid", borderwidth=1)
            label.pack()
            widget.tooltip = tooltip
            
        def hide_tooltip(event):
            if hasattr(widget, 'tooltip'):
                widget.tooltip.destroy()
                
        widget.bind('<Enter>', show_tooltip)
        widget.bind('<Leave>', hide_tooltip)

    def _create_main_layout(self):
        main_container = ttk.Frame(self.root)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        top_frame = ttk.Frame(main_container)
        top_frame.pack(fill=tk.BOTH, expand=True)

        paned = ttk.PanedWindow(top_frame, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)

        detail_frame = ttk.Frame(paned, padding=8, width=200)
        paned.add(detail_frame, weight=1)
        detail_frame.pack_propagate(False)
        detail_frame.config(width=200)

        self.detail_title = ttk.Label(
            detail_frame,
            text=self.lang.get("detail_select_service"),
            font=("Arial", 10, "bold"),
            wraplength=180
        )
        self.detail_title.pack(anchor="w", pady=(0, 8))

        info_frame = ttk.LabelFrame(detail_frame, text=self.lang.get("service_info"), padding=8)
        info_frame.pack(anchor="w", fill=tk.X, pady=(0, 10))
        
        self.detail_status = ttk.Label(info_frame, text=self.lang.get("service_info_status").format("Unknown"), 
                                      font=("Arial", 9))
        self.detail_status.pack(anchor="w", pady=(0, 3))
        
        self.detail_startup = ttk.Label(info_frame, text=self.lang.get("service_info_startup").format("Unknown"), 
                                       font=("Arial", 9))
        self.detail_startup.pack(anchor="w", pady=(0, 3))
        
        self.detail_service_file = ttk.Label(info_frame, text=self.lang.get("service_info_file").format("Unknown"), 
                                            font=("Arial", 8))
        self.detail_service_file.pack(anchor="w")

        desc_frame = ttk.LabelFrame(detail_frame, text=self.lang.get("description_label"), padding=5)
        desc_frame.pack(anchor="w", fill=tk.BOTH, expand=True)
        
        self.detail_description = tk.Text(desc_frame, height=8, wrap=tk.WORD, relief=tk.FLAT, font=("Arial", 9))
        self.detail_description.pack(anchor="w", fill=tk.BOTH, expand=True)

        table_frame = ttk.Frame(paned)
        paned.add(table_frame, weight=4)

        header_frame = ttk.Frame(table_frame)
        header_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(header_frame, text=self.lang.get("label_services"), font=("Arial", 10, "bold")).pack(side=tk.LEFT)
        
        self.service_count = ttk.Label(header_frame, text="", font=("Arial", 9))
        self.service_count.pack(side=tk.RIGHT)

        columns = (self.lang.get("column_name"), self.lang.get("column_description"), 
                  self.lang.get("column_status"), self.lang.get("column_startup_type"))
        self.services_table = ttk.Treeview(table_frame, columns=columns, show="headings", height=20)

        self.services_table.heading(self.lang.get("column_name"), text=self.lang.get("column_name"))
        self.services_table.heading(self.lang.get("column_description"), text=self.lang.get("column_description"))
        self.services_table.heading(self.lang.get("column_status"), text=self.lang.get("column_status"))
        self.services_table.heading(self.lang.get("column_startup_type"), text=self.lang.get("column_startup_type"))

        self.services_table.column(self.lang.get("column_name"), width=200)
        self.services_table.column(self.lang.get("column_description"), width=300)
        self.services_table.column(self.lang.get("column_status"), width=100, anchor='center')
        self.services_table.column(self.lang.get("column_startup_type"), width=120, anchor='center')

        self.services_table.bind('<<TreeviewSelect>>', self.on_service_select)
        self.services_table.bind('<Double-Button-1>', self.on_service_double_click)

        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.services_table.yview)
        self.services_table.configure(yscrollcommand=scrollbar.set)

        self.services_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        bottom_frame = ttk.Frame(main_container)
        bottom_frame.pack(fill=tk.X, pady=(5, 0))

        notebook = ttk.Notebook(bottom_frame, height=80)
        notebook.pack(fill=tk.X)
        
        log_frame = ttk.Frame(notebook)
        self.log_text = tk.Text(log_frame, height=3, wrap=tk.WORD, font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        notebook.add(log_frame, text=self.lang.get("tab_logs"))
        
        self.status_var = tk.StringVar()
        self.status_var.set(self.lang.get("status_ready"))
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def on_service_select(self, event):
        selection = self.services_table.selection()
        if selection:
            values = self.services_table.item(selection[0])['values']
            if values:
                self.current_service = values[0]
                self.update_detail_panel(values)

    def on_service_double_click(self, event):
        self.show_properties()

    def update_detail_panel(self, values):
        if len(values) >= 4:
            name, desc, status, startup = values
            self.detail_title.config(text=name)
            self.detail_status.config(text=self.lang.get("service_info_status").format(status))
            self.detail_startup.config(text=self.lang.get("service_info_startup").format(startup))
            
            service_file = self.lang.get("error_unknown")
            try:
                stdout, stderr, code = self.run_command(f"systemctl show {name} -p FragmentPath")
                if code == 0 and stdout:
                    service_file = stdout.split('=', 1)[1].strip()
                    if len(service_file) > 30:
                        service_file = "..." + service_file[-27:]
            except:
                pass
            self.detail_service_file.config(text=self.lang.get("service_info_file").format(service_file))
            
            self.detail_description.delete(1.0, tk.END)
            self.detail_description.insert(1.0, desc)

    def show_properties(self):
        service = self.get_selected_service()
        if not service:
            messagebox.showwarning(self.lang.get("warning_select_service"), 
                                   self.lang.get("warning_select_service"))
            return
        
        status, description, startup = self.get_service_info(service)
        service_info = (status, description, startup)
        
        ServicePropertiesDialog(self.root, service, service_info, self.lang)

    def run_command(self, command, check_output=True):
        try:
            if check_output:
                result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=15)
                return result.stdout.strip(), result.stderr.strip(), result.returncode
            else:
                subprocess.run(command, shell=True, check=True, timeout=15)
                return "", "", 0
        except subprocess.TimeoutExpired:
            return "", "Command timeout", 1
        except Exception as e:
            return "", str(e), 1

    def get_service_info(self, service_name):
        status = "Unknown"
        description = ""
        startup = "Unknown"
        
        try:
            stdout, stderr, code = self.run_command(f"systemctl status {service_name} --no-pager")
            if code == 0:
                if "active (running)" in stdout:
                    status = "Running"
                elif "inactive" in stdout:
                    status = "Stopped"
                elif "failed" in stdout:
                    status = "Failed"
                elif "activating" in stdout:
                    status = "Starting"
                elif "deactivating" in stdout:
                    status = "Stopping"
                elif "active (exited)" in stdout:
                    status = "Exited"
                
                for line in stdout.split('\n'):
                    if "Description=" in line:
                        description = line.split('=', 1)[1].strip()
                        break
            
            stdout, stderr, code = self.run_command(f"systemctl is-enabled {service_name}")
            if code == 0:
                startup = stdout.strip().capitalize()
            else:
                if "disabled" in stdout.lower():
                    startup = "Disabled"
                elif "masked" in stdout.lower():
                    startup = "Masked"
                    
        except Exception as e:
            status = "Error"
            description = f"Error: {str(e)}"
            
        return status, description, startup

    def list_services(self):
        services = []
        try:
            stdout, stderr, code = self.run_command(
                "systemctl list-unit-files --type=service --no-pager --no-legend"
            )
            if code == 0:
                for line in stdout.split('\n'):
                    if line.strip() and '.service' in line:
                        parts = line.split()
                        if parts:
                            service_name = parts[0]
                            if service_name.endswith('.service'):
                                services.append(service_name)
        except Exception as e:
            self.log(f"Error listing services: {e}")
        return services

    def refresh_services(self):
        self.status_var.set(self.lang.get("status_loading_services"))
        self.services_table.delete(*self.services_table.get_children())
        
        def load_services():
            services = self.list_services()
            service_data = []
            total = len(services)
            
            for i, service in enumerate(services):
                status, desc, startup = self.get_service_info(service)
                service_data.append((service, desc, status, startup))
                
                if i % 10 == 0:
                    self.root.after(0, lambda i=i, total=total: 
                                  self.status_var.set(self.lang.get("status_loading_progress").format(i+1, total)))
            
            self.root.after(0, lambda: self.update_services(service_data))
        
        threading.Thread(target=load_services, daemon=True).start()

    def update_services(self, service_data):
        self.all_services = service_data
        self.filter_services()
        self.service_count.config(text=self.lang.get("total_services").format(len(self.all_services)))
        self.status_var.set(self.lang.get("status_loaded").format(len(self.all_services)))

    def filter_services(self):
        keyword = self.search_var.get().lower()
        self.services_table.delete(*self.services_table.get_children())
        
        filtered = self.all_services
        if keyword:
            filtered = [s for s in self.all_services 
                       if keyword in s[0].lower() or keyword in s[1].lower()]
        
        for service in filtered:
            tags = ()
            if service[2] == "Running":
                tags = ('running',)
            elif service[2] == "Stopped":
                tags = ('stopped',)
            elif service[2] == "Failed":
                tags = ('failed',)
            elif service[2] == "Masked":
                tags = ('masked',)
            
            self.services_table.insert('', tk.END, values=service, tags=tags)
        
        self.services_table.tag_configure('running', foreground='green')
        self.services_table.tag_configure('stopped', foreground='gray')
        self.services_table.tag_configure('failed', foreground='red')
        self.services_table.tag_configure('masked', foreground='orange')
        
        self.service_count.config(text=self.lang.get("total_services").format(len(filtered)))

    def get_selected_service(self):
        selection = self.services_table.selection()
        if not selection:
            return None
        return self.services_table.item(selection[0])['values'][0]

    def show_action_dialog(self, service, action_name, action_command, confirm=True):
        if not service:
            messagebox.showwarning(self.lang.get("warning_select_service"), 
                                   self.lang.get("warning_select_service"))
            return False
            
        if confirm:
            if not messagebox.askyesno(
                self.lang.get("confirm_action"),
                self.lang.get("confirm_action_msg").format(service, action_name)
            ):
                return False
        
        self.status_var.set(f"{action_name}ing {service}...")
        self.log(f"{action_name}ing service: {service}")
        
        def action_thread():
            stdout, stderr, code = self.run_command(f"{action_command} {service}")
            if code == 0:
                self.root.after(0, lambda: messagebox.showinfo(
                    self.lang.get("success_title"), 
                    self.lang.get("success_msg").format(action_name)
                ))
                self.root.after(0, self.refresh_services)
                self.root.after(0, lambda: self.log(f"✓ {action_name} successful: {service}"))
            else:
                self.root.after(0, lambda: messagebox.showerror(
                    self.lang.get("error_title"), 
                    self.lang.get("error_msg").format(action_name, stderr)
                ))
                self.root.after(0, lambda: self.log(f"✗ {action_name} failed: {service} - {stderr}"))
            self.root.after(0, lambda: self.status_var.set(self.lang.get("status_ready")))
        
        threading.Thread(target=action_thread, daemon=True).start()
        return True

    def start_service(self):
        service = self.get_selected_service()
        if service:
            self.show_action_dialog(service, self.lang.get("menu_action_start"), "sudo systemctl start")

    def stop_service(self):
        service = self.get_selected_service()
        if service:
            self.show_action_dialog(service, self.lang.get("menu_action_stop"), "sudo systemctl stop")

    def restart_service(self):
        service = self.get_selected_service()
        if service:
            self.show_action_dialog(service, self.lang.get("menu_action_restart"), "sudo systemctl restart")

    def enable_service(self):
        service = self.get_selected_service()
        if service:
            self.show_action_dialog(service, self.lang.get("menu_action_enable"), "sudo systemctl enable")

    def disable_service(self):
        service = self.get_selected_service()
        if service:
            self.show_action_dialog(service, self.lang.get("menu_action_disable"), "sudo systemctl disable")

    def mask_service(self):
        service = self.get_selected_service()
        if service:
            self.show_action_dialog(service, self.lang.get("menu_action_mask"), "sudo systemctl mask")

    def unmask_service(self):
        service = self.get_selected_service()
        if service:
            self.show_action_dialog(service, self.lang.get("menu_action_unmask"), "sudo systemctl unmask")

    def show_about(self):
        messagebox.showinfo(self.lang.get("about_title"), self.lang.get("about_text"))

    def log(self, message):
        from datetime import datetime
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)


if __name__ == "__main__":
    if os.name != 'posix':
        print("此程式僅支援 Linux 系統（需要 systemctl）")
        exit(1)
    
    if os.geteuid() != 0:
        print("警告：未以 root 權限執行，部分操作可能會失敗。")
        print("建議使用：sudo python3 services_app.py")
    
    root = tk.Tk()
    app = ServicesApp(root)
    root.mainloop()